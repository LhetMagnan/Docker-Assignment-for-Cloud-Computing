<!DOCTYPE html>
<html lang="en">
  <head>

    <title><?php echo "Book Store"; ?></title>

  </head>

  <body>
        <h1>
        WELCOME TO OUR ONLINE BOOK STORE
        </h1>

        <h2>
            This is the list of book available:
        </h2>

        <h4>Book 1:</h4>
        <ul>
        <li>Title:In Search of Lost Time
        <li>Author: Marcel Proust
        <li>Quantity:20
         
        </ul>

        <h4>Book 2:</h4>
        <ul>
        <li>Title: Ulysses
        <li>Author:  James Joyce
        <li>Quantity:20
         
        </ul>

        <h4>Book 3:</h4>
        <ul>
        <li>Title: Don Quixote 
        <li>Author: Miguel de Cervantes
        <li>Quantity:10
         
        </ul>

        <h4>Book 4:</h4>
        <ul>
        <li>Title:The Great Gatsby
        <li>Author:F. Scott Fitzgerald
        <li>Quantity:20
         
        </ul>

        <h1>Thank you
  </body>
    <?php  ?>

   

    