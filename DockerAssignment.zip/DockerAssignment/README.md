<!-- Build Image -->
```sh
docker build -t hello-php .
```
<!-- Run APP -->
```sh
docker run -p 4000:80 -v //L/DockerAssignment/src/:/var/www/html/ hello-php

docker run -p 4000:80 hello-php
```

